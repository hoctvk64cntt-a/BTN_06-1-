 <?php
// 1. Khai báo biến thông tin giải đấu
$tenGiaiDau = "Giải bóng chuyền sinh viên năm 2026";
$monThiDau = "Bóng chuyền";
$soDoi = 6;
$lePhi = 300000;

// 2. Hiển thị thông tin ban đầu
echo "<h2>Thông tin ban đầu</h2>";

echo "Tên giải đấu: " . $tenGiaiDau . "<br>";
echo "Môn thi đấu: " . $monThiDau . "<br>";
echo "Số đội tham gia: " . $soDoi . " đội<br>";
echo "Lệ phí mỗi đội: " . number_format($lePhi, 0, ',', '.') . " đồng<br>";

// 3. Thay đổi giá trị biến số đội
$soDoi = 10;

// 4. Tính tổng lệ phí đăng ký
$tongLePhi = $soDoi * $lePhi;

// 5. Hiển thị thông tin sau khi thay đổi
echo "<h2>Thông tin sau khi thay đổi</h2>";

echo "Tên giải đấu: " . $tenGiaiDau . "<br>";
echo "Môn thi đấu: " . $monThiDau . "<br>";
echo "Số đội tham gia mới: " . $soDoi . " đội<br>";
echo "Tổng lệ phí đăng ký: " . number_format($tongLePhi, 0, ',', '.') . " đồng<br>";

// 6. Nối chuỗi bằng toán tử dấu chấm
$thongBao = "Giải đấu " . $tenGiaiDau .
            " hiện có " . $soDoi . " đội tham gia.";

echo "<h2>Thông báo</h2>";
echo $thongBao;
?>