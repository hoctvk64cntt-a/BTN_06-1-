
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toán tử PHP - Quản lý giải thể thao sinh viên</title>
</head>
<body>

    <h2>Bài 5: Các toán tử trong PHP</h2>

    <?php
        // Khai báo số đội tham gia và số cầu thủ mỗi đội
        $a = 17;
        $b = 5;

        // Các phép toán số học
        echo "<h3>1. Toán tử số học</h3>";
        echo "Số đội đăng ký: $a, Số cầu thủ mỗi đội: $b<br>";
        echo "Phép cộng: " . ($a + $b) . "<br>";
        echo "Phép trừ: " . ($a - $b) . "<br>";
        echo "Phép nhân: " . ($a * $b) . "<br>";
        echo "Phép chia: " . ($a / $b) . "<br>";
        echo "Chia lấy dư: " . ($a % $b) . "<br>";

        // Phép gán kết hợp
        echo "<h3>2. Phép gán kết hợp</h3>";
        $a += 3;
        echo "Sau khi có thêm 3 đội đăng ký, số đội tham gia là: " . $a . "<br>";

        // So sánh giá trị và kiểu dữ liệu
        echo "<h3>3. Toán tử so sánh</h3>";

        echo '5 == "5": ';
        var_dump(5 == "5");
        echo "<br>";

        echo '5 === "5": ';
        var_dump(5 === "5");
        echo "<br>";

        // Phép toán logic
        echo "<h3>4. Toán tử logic</h3>";

        $dieuKien1 = ($a > 10);
        $dieuKien2 = ($b > 0);

        echo "Số đội tham gia lớn hơn 10 và số cầu thủ mỗi đội lớn hơn 0: ";
        var_dump($dieuKien1 && $dieuKien2);
        echo "<br>";
    ?>

</body>
</html>
 