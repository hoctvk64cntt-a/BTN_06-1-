 <!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Cú pháp PHP cơ bản</title>
</head>
<body>
    <h1>
        <?php
        // Hiển thị tên bài thực hành và lời chào.
        echo "Bài tập nhóm 01";
        ?>
    </h1>

    <p>
        <?php
        echo "Đây là bài tập của nhóm 6. Chúng em làm đề tài A26: Quản lý giải thể thao sinh viên.";
        ?>
    </p>
</body>
</html>