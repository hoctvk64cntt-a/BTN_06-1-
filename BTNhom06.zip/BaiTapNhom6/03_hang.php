 
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý giải thể thao sinh viên</title>
</head>
<body>

    <h2>BÀI 3: HẰNG SỐ TRONG PHP</h2>

    <?php
        // Khai báo hằng số phí đăng ký
        const PHI_DANG_KY = 50000;

        // Khai báo các biến thông tin giải đấu
        $tenGiaiDau = "Giải thể thao sinh viên";
        $monThiDau = "Bóng đá";
        $soDoiThamGia = 8;

        // Tính tổng kinh phí đăng ký
        $tongKinhPhi = $soDoiThamGia * PHI_DANG_KY;

        // Hiển thị thông tin giải đấu
        echo "<p>Tên giải đấu: " . $tenGiaiDau . "</p>";
        echo "<p>Môn thi đấu: " . $monThiDau . "</p>";
        echo "<p>Số đội tham gia: " . $soDoiThamGia . "</p>";
        echo "<p>Phí đăng ký mỗi đội: " . number_format(PHI_DANG_KY) . " VND</p>";
        echo "<p>Tổng kinh phí đăng ký: " . number_format($tongKinhPhi) . " VND</p>";
    ?>

</body>
</html>
