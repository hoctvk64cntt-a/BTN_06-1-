 
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý giải thể thao sinh viên</title>
</head>
<body>

    <h2>BÀI 4: KIỂU DỮ LIỆU TRONG PHP</h2>

    <?php
        // Khai báo các kiểu dữ liệu
        $tenGiaiDau = "Giải thể thao sinh viên";
        $soDoiThamGia = 8;
        $phiDangKy = 50000.5;
        $daKetThuc = false;
        $ghiChu = null;

        // Kiểm tra kiểu dữ liệu
        echo "<h3>1. Các kiểu dữ liệu trong PHP</h3>";

        echo "Chuỗi - Tên giải đấu: ";
        var_dump($tenGiaiDau);
        echo "<br><br>";

        echo "Số nguyên - Số đội tham gia: ";
        var_dump($soDoiThamGia);
        echo "<br><br>";

        echo "Số thực - Phí đăng ký: ";
        var_dump($phiDangKy);
        echo "<br><br>";

        echo "Boolean - Trạng thái giải đấu đã kết thúc: ";
        var_dump($daKetThuc);
        echo "<br><br>";

        echo "Null - Ghi chú giải đấu: ";
        var_dump($ghiChu);
        echo "<br><br>";

        // Ép kiểu chuỗi số sang số nguyên
        $chuoiSo = "12";
        $soNguyen = (int)$chuoiSo;

        echo "<h3>2. Ép kiểu dữ liệu</h3>";

        echo "Giá trị ban đầu: ";
        var_dump($chuoiSo);
        echo "<br><br>";

        echo "Giá trị sau khi ép kiểu sang số nguyên: ";
        var_dump($soNguyen);
        echo "<br>";
    ?>

</body>
</html>
