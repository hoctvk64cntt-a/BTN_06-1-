 
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vận dụng PHP - Quản lý giải thể thao sinh viên</title>
</head>
<body>

    <h2>Bài 6: Vận dụng tổng hợp PHP</h2>

    <?php
        // Khai báo hằng tỷ lệ phí
        const TY_LE_PHI = 0.05;

        // Khai báo thông tin mặt hàng
        $tenMatHang = "Áo thi đấu thể thao";
        $soLuong = 3;
        $donGia = 25000;

        // Tính tiền hàng, tiền phí và tổng tiền
        $tienHang = $soLuong * $donGia;
        $tienPhi = $tienHang * TY_LE_PHI;
        $tongTien = ($tienHang + $tienPhi);

        // Hiển thị kết quả
        echo "<h3>THÔNG TIN ĐĂNG KÝ MUA ÁO THI ĐẤU</h3>";

        echo "Tên mặt hàng: " . $tenMatHang . "<br>";
        echo "Số lượng: " . $soLuong . "<br>";
        echo "Đơn giá: " . number_format($donGia) . " VND<br>";
        echo "Tỷ lệ phí: " . (TY_LE_PHI * 100) . "%<br>";

        echo "<h3>KẾT QUẢ THANH TOÁN</h3>";

        echo "Tiền hàng: " . number_format($tienHang) . " VND<br>";
        echo "Tiền phí: " . number_format($tienPhi) . " VND<br>";
        echo "Tổng tiền: " . number_format($tongTien) . " VND<br>";
    ?>

</body>
</html>
